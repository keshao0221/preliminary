#pragma once

#include "../device.hpp"
#include "../graph/graph.hpp"
#include "common/op.hpp"

namespace infinicore::op {

INFINICORE_GRAPH_OP_CLASS(H3RotaryCache, Tensor, const Tensor &, float);

// position_ids: [sequence_length, 3] in (time, height, width) order.
// output: [sequence_length, 6 * rope_freq_dim] with all cosine values first.
Tensor h3_rotary_cache(const Tensor &position_ids,
                       size_t rope_freq_dim = 16,
                       float rope_theta = 10000.0f,
                       DataType dtype = DataType::BF16);

void h3_rotary_cache_(Tensor output,
                      const Tensor &position_ids,
                      float rope_theta = 10000.0f);

} // namespace infinicore::op
